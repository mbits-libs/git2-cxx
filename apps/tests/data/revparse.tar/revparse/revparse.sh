#!/bin/bash

function commit() {
    echo $1 > a-file.txt
    git add a-file.txt
    git commit -m "Commit $2"
    cov report -fempty a-file.txt
    cov tag $2
}

function letter() {
    commit "$1 to $2" $2
}

function root() {
    commit "original ($1)" $1
}

rm -rf revparse
mkdir revparse && cd revparse
git init
cov init
git checkout -b main
cp ../revparse.sh .
git add revparse.sh
root H
letter H G
letter G F
git branch feat/git-1
cov branch feat/cov-1
letter F E
letter E D
git branch feat/git-2
cov branch feat/cov-2
git checkout -b feat/git-3
cov branch feat/cov-3
cov checkout feat/cov-3
letter D C
letter C B
letter B A
git checkout feat/git-2
cov checkout feat/cov-2
letter D J
letter J I

git checkout feat/git-1
cov checkout feat/cov-1
letter F O
letter O N
letter N M
letter M L
letter L K

git checkout --orphan git-separate
cov checkout --orphan cov-separate

cp ../revparse.sh .
git add revparse.sh
root S
letter S R
letter R Q
letter Q P

cov checkout main
git checkout main

cd ..
rm -rf revparse.tar
tar -cf revparse.tar revparse
