void foo() {
    // GCOV_EXCL_START[clang]
    line1();
    line2();
    line3();
    line4();
    // GCOV_EXCL_STOP
}
