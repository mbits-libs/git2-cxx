void foo() {
    // GCOV_EXCL_START
    line1();
    line2();
    line3();
    line4();
    // GCOV_EXCL_START
}
