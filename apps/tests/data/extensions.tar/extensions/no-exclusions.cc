void foo() {
    line1();
    line2();
    line3();
    line4();
}
