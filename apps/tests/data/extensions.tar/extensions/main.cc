module;
import std;

void partial_function_exclusion() /*after*/ {
    line1();
// GCOV_EXCL_START[OS]
    line2();
    line3();
    line4();
}

// GCOV_EXCL_STOP

void sep1() {}
// GCOV_EXCL_START

void partial_function_exclusion1() /*before*/ {
    line1();
    line2();
// GCOV_EXCL_STOP
    line3();
    line4();
}

void sep2() {}

// GCOV_EXCL_START
void full_function_exclusion2() {
    line1();
    line2();
    line3();
    line4();
}
// GCOV_EXCL_STOP

// GCOV_EXCL_START[compilerA,os2]
int main() {
    std::cout << "Hello, world!\n";
}
// GCOV_EXCL_STOP
