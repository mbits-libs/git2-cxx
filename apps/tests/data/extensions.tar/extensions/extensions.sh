#!/bin/bash

function commit() {
    echo $1 > a-file.txt
    git add a-file.txt
    git commit -m "Commit \"$2\""
    cov report -fempty.py a-file.txt
    cov tag $2
}


function root() {
    commit "original ($1)" $1
}

export COV_FILTER_PATH=$COV_FILTER_PATH:../git2-cxx/apps/tests/test-filters

rm -rf extensions
mkdir extensions && cd extensions
git init
git config --local user.name "Johnny Appleseed"
git config --local user.email "johnny@appleseed.com"
cov init
git checkout -b main
cp ../extensions.sh .
cat >>.gitignore <<EOF
report-*
EOF

cat >>main.cc <<EOF
module;
import std;

void partial_function_exclusion() /*after*/ {
    line1();
// GCOV_EXCL_START[OS]
    line2();
    line3();
    line4();
}

// GCOV_EXCL_STOP

void sep1() {}
// GCOV_EXCL_START

void partial_function_exclusion1() /*before*/ {
    line1();
    line2();
// GCOV_EXCL_STOP
    line3();
    line4();
}

void sep2() {}

// GCOV_EXCL_START
void full_function_exclusion2() {
    line1();
    line2();
    line3();
    line4();
}
// GCOV_EXCL_STOP

// GCOV_EXCL_START[compilerA,os2]
int main() {
    std::cout << "Hello, world!\n";
}
// GCOV_EXCL_STOP
EOF

cat >>no-exclusions.cc <<EOF
void foo() {
    line1();
    line2();
    line3();
    line4();
}
EOF

cat >>start-start.cc <<EOF
void foo() {
    // GCOV_EXCL_START
    line1();
    line2();
    line3();
    line4();
    // GCOV_EXCL_START
}
EOF

cat >>start-end.cc <<EOF
void foo() {
    // GCOV_EXCL_START
    line1();
    line2();
    line3();
    line4();
    // GCOV_EXCL_END
}
EOF

cat >>start.cc <<EOF
void foo() {
    // GCOV_EXCL_START
    line1();
    line2();
    line3();
    line4();
}
EOF

cat >>llvm.cc <<EOF
void foo() {
    // GCOV_EXCL_START[llvm]
    line1();
    line2();
    line3();
    line4();
    // GCOV_EXCL_STOP
}
EOF

cat >>clang.cc <<EOF
void foo() {
    // GCOV_EXCL_START[clang]
    line1();
    line2();
    line3();
    line4();
    // GCOV_EXCL_STOP
}
EOF

git add extensions.sh main.cc no-exclusions.cc start-start.cc start-end.cc start.cc llvm.cc clang.cc .gitignore
root extensions

SHA=$(git log -n1 --format=%Hr)
cat <<EOF
{
    "git": {
        "branch": "$(git branch --show-current)",
        "head": "$(git log -n1 --format=%H)"
    }
}
EOF

sha1sum -b main.cc no-exclusions.cc start-start.cc start-end.cc start.cc llvm.cc clang.cc


cd ..
rm -rf extensions.tar
tar -cf extensions.tar extensions
